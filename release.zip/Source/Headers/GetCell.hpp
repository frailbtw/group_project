#pragma once

Cell* get_cell(unsigned char i_x, unsigned char i_y, std::vector<Cell>& i_cells);